<!DOCTYPE html>
<html>
<head>
</head>
    <body>
        <div>
            <a href="http://localhost/authentication/public/reset-password/{{$token}}">Click here</a>
            to reset your password!
        </div>
    </body>
</html>